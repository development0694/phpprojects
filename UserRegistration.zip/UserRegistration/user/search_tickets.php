<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'user') {
    header('Location: ../auth/login.php');
    exit();
}

$routes = $conn->query("SELECT * FROM routes ORDER BY source, destination")->fetch_all(MYSQLI_ASSOC);
$errors = [];
$schedules = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $route_id = $_POST['route_id'] ?? '';
    $date = $_POST['date'] ?? '';
    $errors = [];

    if (empty($route_id)) $errors[] = "Please select a route";
    if (empty($date)) $errors[] = "Please select a date";
    if (strtotime($date) < strtotime(date('Y-m-d'))) $errors[] = "Please select a future date";

    if (empty($errors)) {
        $stmt = $conn->prepare("SELECT s.*, r.source, r.destination, 
                              (SELECT COUNT(*) FROM seats WHERE schedule_id = s.id AND status = 'available') as available_seats 
                              FROM schedules s 
                              JOIN routes r ON s.route_id = r.id 
                              WHERE s.route_id = ? AND s.date = ? AND s.date >= CURDATE()
                              ORDER BY s.time");
        $stmt->bind_param("is", $route_id, $date);
        $stmt->execute();
        $schedules = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Tickets - Online Ticket Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Ticket Booking System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="search_tickets.php">Book Tickets</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../auth/logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0">Search Available Tickets</h4>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <?php foreach ($errors as $error): ?>
                                    <p class="mb-0"><?php echo $error; ?></p>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="route_id" class="form-label">Select Route</label>
                                <select class="form-select" id="route_id" name="route_id" required>
                                    <option value="">Choose a route...</option>
                                    <?php foreach ($routes as $route): ?>
                                        <option value="<?php echo $route['id']; ?>" <?php echo (isset($_POST['route_id']) && $_POST['route_id'] == $route['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($route['source']) . ' to ' . htmlspecialchars($route['destination']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="date" class="form-label">Select Date</label>
                                <input type="date" class="form-control" id="date" name="date" 
                                       min="<?php echo date('Y-m-d'); ?>" 
                                       value="<?php echo isset($_POST['date']) ? $_POST['date'] : ''; ?>" 
                                       required>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Search Tickets</button>
                            </div>
                        </form>

                        <?php if (!empty($schedules)): ?>
                            <hr>
                            <h5 class="mb-4">Available Schedules</h5>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Time</th>
                                            <th>Bus Type</th>
                                            <th>Available Seats</th>
                                            <th>Fare</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($schedules as $schedule): ?>
                                            <tr>
                                                <td><?php echo date('h:i A', strtotime($schedule['time'])); ?></td>
                                                <td><?php echo ucfirst($schedule['bus_type']); ?></td>
                                                <td><?php echo $schedule['available_seats']; ?></td>
                                                <td>$<?php echo number_format($schedule['fare'], 2); ?></td>
                                                <td>
                                                    <?php if ($schedule['available_seats'] > 0): ?>
                                                        <a href="book_ticket.php?id=<?php echo $schedule['id']; ?>" class="btn btn-sm btn-primary">Book Now</a>
                                                    <?php else: ?>
                                                        <span class="badge bg-danger">Sold Out</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($errors)): ?>
                            <div class="alert alert-info mt-4">
                                No schedules found for the selected route and date.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>