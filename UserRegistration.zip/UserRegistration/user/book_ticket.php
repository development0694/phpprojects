<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'user') {
    header('Location: ../auth/login.php');
    exit();
}

$schedule_id = $_GET['id'] ?? 0;
$errors = [];
$success = false;

// Get schedule details
$stmt = $conn->prepare("SELECT s.*, r.source, r.destination 
                        FROM schedules s 
                        JOIN routes r ON s.route_id = r.id 
                        WHERE s.id = ? AND s.date >= CURDATE()");
$stmt->bind_param("i", $schedule_id);
$stmt->execute();
$schedule = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$schedule) {
    header('Location: search_tickets.php');
    exit();
}

// Get available seats
$stmt = $conn->prepare("SELECT * FROM seats WHERE schedule_id = ? AND status = 'available'");
$stmt->bind_param("i", $schedule_id);
$stmt->execute();
$available_seats = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selected_seats = $_POST['seats'] ?? [];
    $payment_method = $_POST['payment_method'] ?? '';

    if (empty($selected_seats)) $errors[] = "Please select at least one seat";
    if (empty($payment_method)) $errors[] = "Please select a payment method";

    if (empty($errors)) {
        $conn->begin_transaction();
        try {
            // Calculate total amount
            $total_amount = count($selected_seats) * $schedule['fare'];

            // Create booking
            $stmt = $conn->prepare("INSERT INTO bookings (user_id, schedule_id, total_amount, status) VALUES (?, ?, ?, 'confirmed')");
            $stmt->bind_param("iid", $_SESSION['user_id'], $schedule_id, $total_amount);
            $stmt->execute();
            $booking_id = $conn->insert_id;
            $stmt->close();

            // Update seat status
            $stmt = $conn->prepare("UPDATE seats SET status = 'booked' WHERE schedule_id = ? AND seat_no = ?");
            foreach ($selected_seats as $seat) {
                $stmt->bind_param("is", $schedule_id, $seat);
                $stmt->execute();
            }
            $stmt->close();

            // Create payment record
            $transaction_id = 'TXN' . time() . rand(1000, 9999);
            $stmt = $conn->prepare("INSERT INTO payments (booking_id, amount, method, status, transaction_id) VALUES (?, ?, ?, 'completed', ?)");
            $stmt->bind_param("idss", $booking_id, $total_amount, $payment_method, $transaction_id);
            $stmt->execute();
            $stmt->close();

            $conn->commit();
            $success = true;
            header("Location: view_ticket.php?id=" . $booking_id);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            $errors[] = "Booking failed. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Ticket - Online Ticket Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .seat-layout {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
            margin: 20px 0;
        }
        .seat {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
            cursor: pointer;
            border-radius: 5px;
        }
        .seat.available {
            background-color: #e9ecef;
        }
        .seat.selected {
            background-color: #28a745;
            color: white;
        }
        .seat.booked {
            background-color: #dc3545;
            color: white;
            cursor: not-allowed;
        }
    </style>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Ticket Booking System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="search_tickets.php">Book Tickets</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../auth/logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0">Book Ticket</h4>
                    </div>
                    <div class="card-body">
                        <div class="mb-4">
                            <h5>Journey Details</h5>
                            <p class="mb-1"><strong>Route:</strong> <?php echo htmlspecialchars($schedule['source']) . ' to ' . htmlspecialchars($schedule['destination']); ?></p>
                            <p class="mb-1"><strong>Date:</strong> <?php echo date('d M Y', strtotime($schedule['date'])); ?></p>
                            <p class="mb-1"><strong>Time:</strong> <?php echo date('h:i A', strtotime($schedule['time'])); ?></p>
                            <p class="mb-1"><strong>Bus Type:</strong> <?php echo ucfirst($schedule['bus_type']); ?></p>
                            <p class="mb-0"><strong>Fare per seat:</strong> $<?php echo number_format($schedule['fare'], 2); ?></p>
                        </div>

                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <?php foreach ($errors as $error): ?>
                                    <p class="mb-0"><?php echo $error; ?></p>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="" id="bookingForm">
                            <h5>Select Seats</h5>
                            <div class="seat-layout">
                                <?php
                                $total_seats = 40; // Assuming 40 seats per bus
                                for ($i = 1; $i <= $total_seats; $i++) {
                                    $seat_no = sprintf("%02d", $i);
                                    $is_available = false;
                                    foreach ($available_seats as $seat) {
                                        if ($seat['seat_no'] === $seat_no) {
                                            $is_available = true;
                                            break;
                                        }
                                    }
                                    $class = $is_available ? 'available' : 'booked';
                                    echo "<div class='seat $class' data-seat='$seat_no'>";
                                    echo "Seat $seat_no";
                                    if ($is_available) {
                                        echo "<input type='checkbox' name='seats[]' value='$seat_no' style='display:none;'>";
                                    }
                                    echo "</div>";
                                }
                                ?>
                            </div>

                            <div class="mb-3">
                                <h5>Payment Method</h5>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="payment_method" id="credit_card" value="credit_card" required>
                                    <label class="form-check-label" for="credit_card">Credit Card</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="payment_method" id="debit_card" value="debit_card">
                                    <label class="form-check-label" for="debit_card">Debit Card</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="payment_method" id="net_banking" value="net_banking">
                                    <label class="form-check-label" for="net_banking">Net Banking</label>
                                </div>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Proceed to Payment</button>
                                <a href="search_tickets.php" class="btn btn-secondary">Back to Search</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const seats = document.querySelectorAll('.seat.available');
            seats.forEach(seat => {
                seat.addEventListener('click', function() {
                    const checkbox = this.querySelector('input[type="checkbox"]');
                    if (checkbox) {
                        checkbox.checked = !checkbox.checked;
                        this.classList.toggle('selected');
                    }
                });
            });
        });
    </script>
</body>
</html>